--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2 (Ubuntu 14.2-1.pgdg18.04+1)
-- Dumped by pg_dump version 14.2 (Ubuntu 14.2-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "rct-db";
--
-- Name: rct-db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "rct-db" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'pl_PL.UTF-8';


ALTER DATABASE "rct-db" OWNER TO postgres;

\connect -reuse-previous=on "dbname='rct-db'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: beams_dictionary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.beams_dictionary (id, beam_type) FROM stdin;
\.
COPY public.beams_dictionary (id, beam_type) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: pass_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pass_types (id, pass_type) FROM stdin;
\.
COPY public.pass_types (id, pass_type) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: data_passes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_passes (id, name, description, pass_type, jira, ml, number_of_events, software_version, size) FROM stdin;
\.
COPY public.data_passes (id, name, description, pass_type, jira, ml, number_of_events, software_version, size) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.periods (id, name, year, beam_type_id) FROM stdin;
\.
COPY public.periods (id, name, year, beam_type_id) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.runs (id, period_id, run_number, start, "end", b_field, energy_per_beam, ir, filling_scheme, triggers_conf, fill_number, run_type, mu, time_trg_start, time_trg_end) FROM stdin;
\.
COPY public.runs (id, period_id, run_number, start, "end", b_field, energy_per_beam, ir, filling_scheme, triggers_conf, fill_number, run_type, mu, time_trg_start, time_trg_end) FROM '$$PATH$$/3366.dat';

--
-- Data for Name: data_passes_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_passes_runs (id, run_id, data_pass_id) FROM stdin;
\.
COPY public.data_passes_runs (id, run_id, data_pass_id) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: detectors_subsystems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detectors_subsystems (id, name) FROM stdin;
\.
COPY public.detectors_subsystems (id, name) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: flags_types_dictionary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flags_types_dictionary (id, flag) FROM stdin;
\.
COPY public.flags_types_dictionary (id, flag) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: runs_detectors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.runs_detectors (id, detector_id, run_id) FROM stdin;
\.
COPY public.runs_detectors (id, detector_id, run_id) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: quality_control_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quality_control_flags (id, pass_run_id, run_detector_id, start, "end", flag_type_id, comment) FROM stdin;
\.
COPY public.quality_control_flags (id, pass_run_id, run_detector_id, start, "end", flag_type_id, comment) FROM '$$PATH$$/3362.dat';

--
-- Data for Name: simulation_passes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulation_passes (id, name, description, jira, ml, pwg, number_of_events) FROM stdin;
\.
COPY public.simulation_passes (id, name, description, jira, ml, pwg, number_of_events) FROM '$$PATH$$/3369.dat';

--
-- Data for Name: sim_and_data_passess; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sim_and_data_passess (data_pass_id, sim_pass_id) FROM stdin;
\.
COPY public.sim_and_data_passess (data_pass_id, sim_pass_id) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: simulation_passes_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.simulation_passes_runs (id, simulation_pass_id, run_id, qc) FROM stdin;
\.
COPY public.simulation_passes_runs (id, simulation_pass_id, run_id, qc) FROM '$$PATH$$/3371.dat';

--
-- Name: beams_dictionary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.beams_dictionary_id_seq', 5, true);


--
-- Name: data_passes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.data_passes_id_seq', 70, true);


--
-- Name: data_passes_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.data_passes_runs_id_seq', 2432, true);


--
-- Name: detectors_subsystems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detectors_subsystems_id_seq', 15, true);


--
-- Name: flags_types_dictionary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.flags_types_dictionary_id_seq', 8, true);


--
-- Name: pass_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pass_types_id_seq', 2, true);


--
-- Name: periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.periods_id_seq', 30, true);


--
-- Name: quality_control_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.quality_control_flags_id_seq', 6026, true);


--
-- Name: runs_detectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.runs_detectors_id_seq', 3134, true);


--
-- Name: runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.runs_id_seq', 1200, true);


--
-- Name: simulation_passes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.simulation_passes_id_seq', 100, true);


--
-- Name: simulation_passes_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.simulation_passes_runs_id_seq', 5237, true);


--
-- PostgreSQL database dump complete
--

